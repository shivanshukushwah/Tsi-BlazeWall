from flask import Flask, request, Response
import requests
import re
import logging

app = Flask(__name__)

# ✅ Configure Logging (Logs will be displayed in the terminal)
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO
)

# ✅ SQL Injection Detection Patterns
SQLI_PATTERNS = [
    r"(?i)UNION.*SELECT",
    r"(?i)SELECT.*FROM",
    r"(?i)INSERT.*INTO",
    r"(?i)DROP.*TABLE",
    r"(?i)UPDATE.*SET",
    r"(?i)DELETE.*FROM",
    r"(--|#|\/\*|\*\/)",
    r"(?i)OR.*1\s*=\s*1"
]

def is_sql_injection(query):
    """Check if the request contains an SQL injection pattern."""
    for pattern in SQLI_PATTERNS:
        if re.search(pattern, query):
            return True
    return False

@app.route('/', defaults={'path': ''}, methods=['GET', 'POST', 'PUT', 'DELETE'])
@app.route('/<path:path>', methods=['GET', 'POST', 'PUT', 'DELETE'])
def proxy(path):
    """Forward requests to any website, logging all requests, and blocking SQL Injection attempts."""

    target = request.args.get('target')
    if not target:
        logging.warning("❌ Request blocked: No target URL provided.")
        return "Error: No target URL provided.", 400

    full_url = f"{target}/{path}"

    # Log incoming request details
    logging.info(f"🔗 Incoming Request → {request.method} {full_url}")
    logging.info(f"📥 Headers: {dict(request.headers)}")
    logging.info(f"📜 Body: {request.get_data(as_text=True)}")

    # 🔍 Check for SQL Injection in URL, headers, or body
    if is_sql_injection(request.url) or is_sql_injection(str(request.headers)) or is_sql_injection(request.get_data(as_text=True)):
        logging.error("🚨 SQL Injection detected! Request blocked.")
        return "🚨 SQL Injection attempt detected! Request blocked.", 403

    # 🔄 Forward the request to the actual target
    response = requests.request(
        method=request.method,
        url=full_url,
        headers={key: value for key, value in request.headers if key.lower() != 'host'},
        data=request.get_data(),
        cookies=request.cookies,
        allow_redirects=True
    )

    # Log the response status
    logging.info(f"✅ Response Status: {response.status_code}")

    # 🔄 Return the response back to the client
    return Response(response.content, response.status_code, response.headers.items())

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
