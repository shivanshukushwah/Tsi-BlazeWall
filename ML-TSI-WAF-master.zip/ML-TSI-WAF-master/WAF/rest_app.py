'''Implementation of the simple rest service that can be used for testing of the WAF.'''
from flask import Flask, request, jsonify
import re
from classifier import predict_attack  # Assuming this is the ML model function

app = Flask(__name__)

# SQL Injection Detection Function
def is_sql_injection(query):
    sql_patterns = [
        r"(?i)(union.*select)", r"(?i)(select.*from)", r"(?i)(insert.*into)",
        r"(?i)(delete.*from)", r"(?i)(drop\s+table)", r"(--|#|;)"
    ]
    return any(re.search(pattern, query) for pattern in sql_patterns)

@app.route('/check', methods=['POST'])
def check_request():
    data = request.json
    if not data or 'query' not in data:
        return jsonify({"error": "Invalid request"}), 400
    
    query = data['query']

    # First, check for SQL Injection
    if is_sql_injection(query):
        return jsonify({"status": "blocked", "reason": "SQL Injection detected"}), 403
    
    # If no SQLi, run ML-based classification
    prediction = predict_attack(query)
    if prediction == "malicious":
        return jsonify({"status": "blocked", "reason": "ML detected attack"}), 403
    
    return jsonify({"status": "allowed", "message": "Request is safe"})

if __name__ == '__main__':
    app.run(debug=True)
python