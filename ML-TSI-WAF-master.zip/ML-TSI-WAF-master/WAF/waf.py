from flask import Flask, request, jsonify
import re

app = Flask(__name__)

def is_sql_injection(query):
    """Simple rule-based SQL injection detection."""
    sql_patterns = [
        r"(?i)(union.*select)",  # UNION SELECT attacks
        r"(?i)(select.*from)",  # Basic SELECT queries
        r"(?i)(insert.*into)",  # INSERT queries
        r"(?i)(delete.*from)",  # DELETE queries
        r"(?i)(drop\s+table)",  # DROP TABLE queries
        r"(--|#|;)"  # SQL comments
    ]
    return any(re.search(pattern, query) for pattern in sql_patterns)

@app.route('/check', methods=['POST'])
def check_request():
    data = request.json
    if not data or 'query' not in data:
        return jsonify({"error": "Invalid request"}), 400
    
    query = data['query']
    if is_sql_injection(query):
        return jsonify({"status": "blocked", "reason": "SQL Injection detected"}), 403
    return jsonify({"status": "allowed", "message": "Request is safe"})

if __name__ == '__main__':
    app.run(debug=True)
