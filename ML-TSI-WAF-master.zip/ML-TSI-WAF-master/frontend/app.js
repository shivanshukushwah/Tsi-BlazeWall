import { useState } from "react";
    import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

    function App() {
      const [data, setData] = useState([]);
      const [prediction, setPrediction] = useState(null);

      const fetchData = async () => {
        const response = await fetch("http://127.0.0.1:5000/api/data");
        const result = await response.json();
        setData(result.data);
      };

      const handlePredict = async () => {
        const response = await fetch("http://127.0.0.1:5000/api/predict", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ data }),
        });
        const result = await response.json();
        setPrediction(result.prediction);
      };

      return (
        <div>
          <h1>ML Dashboard</h1>
          <button onClick={fetchData}>Load Data</button>
          <button onClick={handlePredict}>Predict</button>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="x" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="y" stroke="#8884d8" />
            </LineChart>
          </ResponsiveContainer>
          {prediction && <p>Prediction: {JSON.stringify(prediction)}</p>}
        </div>
      );
    }

    export default App;